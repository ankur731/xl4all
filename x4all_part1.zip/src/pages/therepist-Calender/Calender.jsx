import * as React from 'react';
import { useState } from 'react';
import { styled, createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Link from '@mui/material/Link';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
// import Sideitems from '../../components/SidenavbarItems/SideItems';
import Sideitems from '../../components/SidenavbarItems/SideItems';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
// import AppointmentCard from '../../components/therepist/AppointmentCard';
import Button from '@mui/material/Button';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Calendar from 'moedim';
import TimeRange from "react-time-range";
import moment from "moment";
import TherepistSlotCard from '../../components/therepist/TherepistSlotCard';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import { TimePicker } from 'antd';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';

function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © Developed By '}
            <Link color="inherit" href="https://mui.com/">
                Rhombus
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}
export function BasicDateCalendar() {
    return (
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DateCalendar />
      </LocalizationProvider>
    );
  }

const drawerWidth = 240;

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        '& .MuiDrawer-paper': {
            position: 'relative',
            whiteSpace: 'nowrap',
            width: drawerWidth,
            transition: theme.transitions.create('width', {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
            boxSizing: 'border-box',
            ...(!open && {
                overflowX: 'hidden',
                transition: theme.transitions.create('width', {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.leavingScreen,
                }),
                width: theme.spacing(7),
                [theme.breakpoints.up('sm')]: {
                    width: theme.spacing(9),
                },
            }),
        },
    }),
);

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();



export default function Calender() {
    const [open, setOpen] = React.useState(true);
    const toggleDrawer = () => {
        setOpen(!open);
    };

    const [date, setDate] = useState(new Date());
    const [slotCards, setSlotCard] = useState([]);
    const [slotDate, setSlotDate] = useState("");
    const [slotTime, setSlotTime] = useState("0");
    const calenderChange = (d) => {
        // console.log(d)
        setSlotDate(d.toString().slice(3,10));
        setDate(d);
    }

    const [time, setTime]=  useState([]);
    
    const timeChange = (time, timeString) => {
        // console.log(time)
        // console.log(timeString);
        setTime(time)
        setSlotTime(timeString[0]+" - "+timeString[1]);
    };
    
    const AddSlot = event=>{
         setSlotCard(slotCards.concat(AddSlotCard(slotDate, slotTime)));
    }
    const removeCard = ()=>{
        console.log('clicked')
        slotCards.slice(0,-1);
        const newSlotCards = slotCards
        setSlotCard(newSlotCards);
    }
    
    const AddSlotCard = (date, time)=>{
        return <Grid item  >
        <Paper   onClick={removeCard}
        sx={{
            p: 2,
            display: 'flex',
            flexDirection: 'column',
            height: 80,
            background: '#ececec',
            position:'relative',
            minWidth:'180px',
            margin:"10px"
        }}
    >
        <h6>{date}</h6>
        <h6>{time}</h6>
        <CloseOutlinedIcon fontSize='small' sx={{
            position:'absolute',
            right:"10px",
            top:"10px"
        }}/>
    </Paper>
    </Grid>
    }
    const navigate = useNavigate();
    
    const gotopatientdetail = () => {
        // 👇️ navigate to /
        navigate('/patient/patient-detail');
    };


    return (
        <ThemeProvider theme={defaultTheme}>
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />
                <AppBar position="absolute" open={open}>
                    <Toolbar
                        sx={{
                            pr: '24px', // keep right padding when drawer closed
                            backgroundColor:"#f5f5f7",
                            border:"none"
                        }}
                    >
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={toggleDrawer}
                            sx={{
                                color:"#000",
                                marginRight: '36px',
                                ...(open && { display: 'none' }),
                            }}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography
                            component="h1"
                            variant="h6"
                            color="#000"
                            noWrap
                            sx={{ flexGrow: 1 }}
                        >
                            Hi, Dr. Samantha 
                        </Typography>
                        <IconButton color="inherit">
                            <Badge badgeContent={4} color="secondary" style={{ "margin-right": "30px" }}>
                                <NotificationsIcon style={{fill:"#000"}}/>
                            </Badge>
                            <PopupState variant="popover" popupId="demo-popup-menu">
                                {(popupState) => (
                                    <React.Fragment>
                                        <Avatar alt="Cindy Baker" {...bindTrigger(popupState)} src={require("../../images/person.jpg")} />
                                        <Menu {...bindMenu(popupState)}>
                                            <MenuItem onClick={popupState.close}><PersonOutlinedIcon /> Profile</MenuItem>
                                            <MenuItem onClick={popupState.close}><LogoutOutlinedIcon /> Logout</MenuItem>
                                        </Menu>
                                    </React.Fragment>
                                )}
                            </PopupState>

                        </IconButton>
                    </Toolbar>
                </AppBar>
                <Drawer variant="permanent" open={open} sx={{
                     backgroundColor:"#021138"
                }}>
                    <Toolbar
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            px: [1],
                            backgroundColor:"#021138",
                            border:"none"
                        }}
                    >
                        <IconButton onClick={toggleDrawer}>
                            {/* <p style={{
                                "display": "flex",
                                "margin": "auto",
                                "position": "relative",
                                "left": "-47%"
                            }}>Full Screen</p> */}
                            <MenuIcon sx={{
                                color:"#fff",
                                position:"absolute",
                                top:"22px",
                                right:'15px',
                                }}/>
                            <img style={{
                                width:"210px"
                            }} src={require("../../images/speech4all.png")} alt='logo'/>
                        </IconButton>
                    </Toolbar>
                    {/* <Divider /> */}
                    <List component="nav" sx={{
                        backgroundColor:"#021138",
                        color:"#fff",
                        height:"80%"
                    }}>
                        <Sideitems />
                        {/* <Divider sx={{ my: 1 }} /> */}
                        {/* {secondaryListItems} */}
                    </List>
                </Drawer>
                <Box
                    component="main"
                    sx={{
                        backgroundColor: (theme) =>
                            theme.palette.mode === 'light'
                                ? theme.palette.grey[100]
                                : theme.palette.grey[900],
                        flexGrow: 1,
                        height: '100vh',
                        overflow: 'auto',
                        padding: ' 0 10px'
                    }}
                >
                    <Toolbar />
                    <Container maxWidth="lg" sx={{
                        mt: 4,
                        mb: 4,
                        backgroundColor: "#fff",
                        borderRadius: '10px',
                        padding: "15px 0 10px 0",

                    }}>
                                <h5>Add your slot timing</h5>
                        <Grid container spacing={2}  sx={{ justifyContent: 'center', padding: 2 }}>
                            <Grid item sm={0} md={1}>
                            
                            </Grid>
                            <Grid item xs={12} sm={10} md={5}>
                                <Calendar value={date} onChange={(d) => calenderChange(d)} />
                                {/* <BasicDateCalendar value={date} onChange={(d) => calenderChange(d)} /> */}
                            </Grid>
                            <Grid item xs={12} sm={10} md={6} >
                              
                                   <Grid item>
                                   {/* <TimeRange
                                        onStartTimeChange={returnFunctionStart}
                                        onEndTimeChange={returnFunctionEnd}
                                        startMoment={startTime}
                                        endMoment={endTime}
                                        minuteIncrement={15}
                                        sameIsValid={false}
                                    /> */}
                                    <TimePicker.RangePicker sx={{
                                        width:"100%"
                                    }}
                                        use12Hours format="h:mm a"
                                        showSecond={false}
                                        minuteStep={10}
                                        // onSelect={updateSlot}
                                        onChange={timeChange}
                                        
                                    />
                               
                                   </Grid>  
                                     <Button style={{width:"260px", marginTop:'15px'}} onClick={AddSlot} variant="contained">Add</Button>
                              
                                   <Grid container   mt={2}  xs={12} md={8} lg={12}>
                                    
                                   
                               
                                {slotCards}
                                
                                
                        
                                   </Grid>
                            </Grid>
                            
                            <Grid item sm={0} md={2}>
                            </Grid>
                        </Grid>





                        {/* <Copyright sx={{ pt: 4 }} /> */}
                    </Container>

                </Box>
            </Box>
        </ThemeProvider >
    );
}
