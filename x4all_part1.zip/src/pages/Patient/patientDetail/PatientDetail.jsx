import * as React from 'react';
import { styled, createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Link from '@mui/material/Link';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
// import Sideitems from '../../components/SidenavbarItems/SideItems';
import Sideitems from '../../../components/SidenavbarItems/SideItems';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import "./PatientDetail.css"
import { LineChart, Line, CartesianGrid, XAxis, YAxis } from 'recharts';
import ActivityPage from '../../../components/ActivityPage';
import Chart from '../../../components/patient/Chart';


function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © Developed By '}
            <Link color="inherit" href="https://mui.com/">
                Rhombus
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const drawerWidth = 240;

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        '& .MuiDrawer-paper': {
            position: 'relative',
            whiteSpace: 'nowrap',
            width: drawerWidth,
            transition: theme.transitions.create('width', {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
            boxSizing: 'border-box',
            ...(!open && {
                overflowX: 'hidden',
                transition: theme.transitions.create('width', {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.leavingScreen,
                }),
                width: theme.spacing(7),
                [theme.breakpoints.up('sm')]: {
                    width: theme.spacing(9),
                },
            }),
        },
    }),
);

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();


//----------------Chart data-------------
const data1 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35];
const data2 = [1,1,2,2,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,17,17,18,19,20,21,22,23,24,25,26,27,28,29];
const labels = ["1", "6", "11", "16", "21", "26", "31", "36", "41", "46", "51", "56", "61", "66", "71", "76", "81", "86", "91", "96", "101", "106", "111", "116", "121", "126", "131", "136","141","146", "151", "156", "161", "166", "171"]
const data = {
    labels: labels,
    datasets: [
      {
        label: "Expected Progress",
        data: data1,
        borderColor: "#00bf63"
      },
      {
        label: "Actual Progress",
        data: data2,
        fill: false,
        borderColor: "#2242a3"
      }
    ],
  }

  const options = {
    scales: {
      x: {
        type: 'category', // Use 'category' scale for X-axis when using labels
        title: {
          display: true,
          text: 'Days',
        },
      },
      y: {
        title: {
          display: true,
          text: 'Trials',
        },
      },
    },
    maintainAspectRatio: false
  };

export default function Patientdetail() {
    const [open, setOpen] = React.useState(true);
    const toggleDrawer = () => {
        setOpen(!open);
    };
    // const data = [{name: 'Page A', uv: 400, pv: 2400, amt: 2400}];

    return (
        <ThemeProvider theme={defaultTheme}>
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />
                <AppBar position="absolute" open={open}>
                    <Toolbar
                        sx={{
                            pr: '24px', // keep right padding when drawer closed
                            backgroundColor:"#f5f5f7",
                            border:"none"
                        }}
                    >
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={toggleDrawer}
                            sx={{
                                color:"#000",
                                marginRight: '36px',
                                ...(open && { display: 'none' }),
                            }}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography
                            component="h1"
                            variant="h6"
                            color="#000"
                            noWrap
                            sx={{ flexGrow: 1 }}
                        >
                            Hi, Login User Name
                        </Typography>
                        <IconButton color="inherit">
                            <Badge badgeContent={4} color="secondary" style={{ "margin-right": "30px" }}>
                                <NotificationsIcon style={{fill:"#000"}}/>
                            </Badge>
                            <PopupState variant="popover" popupId="demo-popup-menu">
                                {(popupState) => (
                                    <React.Fragment>
                                        <Avatar alt="Cindy Baker" {...bindTrigger(popupState)} src={require("../../../images/person.jpg")}  />
                                        <Menu {...bindMenu(popupState)}>
                                            <MenuItem onClick={popupState.close}><PersonOutlinedIcon /> Profile</MenuItem>
                                            <MenuItem onClick={popupState.close}><LogoutOutlinedIcon /> Logout</MenuItem>
                                        </Menu>
                                    </React.Fragment>
                                )}
                            </PopupState>

                        </IconButton>
                    </Toolbar>
                </AppBar>
                <Drawer variant="permanent" open={open} sx={{
                     backgroundColor:"#021138"
                }}>
                    <Toolbar
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            px: [1],
                            backgroundColor:"#021138",
                            border:"none"
                        }}
                    >
                        <IconButton onClick={toggleDrawer}>
                            {/* <p style={{
                                "display": "flex",
                                "margin": "auto",
                                "position": "relative",
                                "left": "-47%"
                            }}>Full Screen</p> */}
                            <MenuIcon sx={{
                                color:"#fff",
                                position:"absolute",
                                top:"22px",
                                right:'15px',
                                }}/>
                            <img style={{
                                width:"210px"
                            }} src={require("../../../images/speech4all.png")} alt='logo'/>
                        </IconButton>
                    </Toolbar>
                    {/* <Divider /> */}
                    <List component="nav" sx={{
                        backgroundColor:"#021138",
                        color:"#fff",
                        height:"80%"
                    }}>
                        <Sideitems />
                        {/* <Divider sx={{ my: 1 }} /> */}
                        {/* {secondaryListItems} */}
                    </List>
                </Drawer>
                <Box
                    component="main"
                    sx={{
                        backgroundColor: (theme) =>
                            theme.palette.mode === 'light'
                                ? theme.palette.grey[100]
                                : theme.palette.grey[900],
                        flexGrow: 1,
                        height: '100vh',
                        overflow: 'auto',
                        padding: ' 0 10px'
                    }}
                >
                    <Toolbar />
                    <Container maxWidth="lg" sx={{
                        mt: 4,
                        mb: 4,
                        backgroundColor: "#fff",
                        borderRadius: '10px',
                        padding: "15px "
                    }}>
                        <Grid container spacing={3} sx={{
                            alignItems: "center",
                            padding: "10px"
                        }}>
                            <Grid item xs={2}>
                                <img className='patient-detail-img' src={require('../../../images/person.jpg')} alt='personImg' />
                            </Grid>
                            <Grid item xs={5}>
                                <h6><strong>Abhsihek patil</strong></h6>
                                <p>London, UK ( GMT+05:30 )</p>
                            </Grid>

                        </Grid>
                        <Grid container columnSpacing={{ sm: 4, md: 4 }} maxWidth="lg" sx={{
                            mt: 4,
                            justifyContent: "space-around",
                            padding: "10px"
                        }}>
                            <Grid item sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                                gap:"0 40px",
                            }} xs={12} sm={6} md={5}>
                                <h5 >Name of the Parent</h5>
                                <p >Abhishek Upmanyu</p>
                            </Grid>
                            <Grid item sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                                gap:"0 40px",

                            }} xs={12} sm={6} md={5}>
                                <h5 >Name of the Student</h5>
                                <p >Sanjeev Upmanyu</p>
                            </Grid>
                            <Grid item sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                                gap:"0 40px",

                            }} xs={12} sm={6} md={5}>
                                <h5 >Age of the student</h5>
                                <p >16</p>
                            </Grid>
                            <Grid item sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                                gap:"0 40px",

                            }} xs={12} sm={6} md={5}>
                                <h5 >Primary Language Spoken</h5>
                                <p >English</p>
                            </Grid>
                            <Grid item sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                                gap:"0 40px",

                            }} xs={12} sm={6} md={5}>
                                <h5 >Country</h5>
                                <p >India</p>
                            </Grid>
                            <Grid item sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                                gap:"0 40px",

                            }} xs={12} sm={6} md={5}>
                                <h5 >Timezone</h5>
                                <p >GMT + 05:30</p>
                            </Grid>


                        </Grid>
                        <Grid  sx={{
                            mt: 2
                        }}>
                            <h5>Expectation from Therepy</h5>
                            <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</p>
                        </Grid>
                        <h5>Activity</h5>
                        <Grid container>
                            <ActivityPage />
                        </Grid>
                            <Grid item sx={{
                                mt:4
                            }}>
                            <h5>Activity Chart</h5>
                            </Grid>
                        <Grid container sx={{
                            mt: 2,
                            display:"flex",
                            justifyContent:"space-between",    
                            alignItems:"center",
                        }}>
                            <Grid item xs={12}  md={6}>
                                 <Chart  data={data} options={options}/>
                            </Grid>
                            <Grid item xs={12}  md={5} >
                           
                            <Grid item xs={12} lg={9}>
                                <Paper
                                    sx={{
                                        p: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        height: 100,
                                        background: '#eeecf9'
                                    }}
                                >
                                     <h5 style={{ "textAlign": 'center' }}>Total Session</h5>
                                    <h2 style={{ "textAlign": 'center' }}>25</h2>
                                </Paper>
                            </Grid>
                            <Grid sx={{marginTop:'10px'}} item xs={12} lg={9} >
                                <Paper
                                    sx={{
                                        p: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        height: 100,
                                        background: '#fdf6e9',
                                    }}
                                >
                                    <h5 style={{ "textAlign": 'center' }}>Upcoming Session</h5>
                                    <h2 style={{ "textAlign": 'center' }}>5</h2>
                                </Paper>
                            </Grid>

                            </Grid>
                        </Grid>



                        {/* <Copyright sx={{ pt: 4 }} /> */}
                    </Container>
                    
                </Box>
            </Box>
        </ThemeProvider >
    );
}
