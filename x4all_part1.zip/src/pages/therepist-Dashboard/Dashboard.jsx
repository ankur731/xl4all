import * as React from 'react';
import { styled, createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Link from '@mui/material/Link';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import Sideitems from '../../components/SidenavbarItems/SideItems';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import AppointmentCard from '../../components/therepist/AppointmentCard';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import Calendar from 'moedim';
import "./Dashboard.css";
import {Route, Routes, useLocation} from 'react-router-dom';
import Chart from '../../components/patient/Chart';



function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © Developed By '}
            <Link color="inherit" href="https://mui.com/">
                Rhombus
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

function BasicDateCalendar() {
    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DateCalendar />
        </LocalizationProvider>
    );
}

const drawerWidth = 240;

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        '& .MuiDrawer-paper': {
            position: 'relative',
            whiteSpace: 'nowrap',
            width: drawerWidth,
            transition: theme.transitions.create('width', {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
            boxSizing: 'border-box',
            ...(!open && {
                overflowX: 'hidden',
                transition: theme.transitions.create('width', {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.leavingScreen,
                }),
                width: theme.spacing(7),
                [theme.breakpoints.up('sm')]: {
                    width: theme.spacing(9),
                },
            }),
        },
    }),
);

// TODO remove, this demo shouldn't need to reset the theme.
// const defaultTheme = createTheme();
const defaultTheme = createTheme({
    palette: {
        primary: {
            light: '#fff',
            main: '#f5f5f7',
            dark: '#002884',
            contrastText: '#fff',
        },
        secondary: {
            light: '#ff7961',
            main: '#f44336',
            dark: '#ba000d',
            contrastText: '#000',
        },
    },
});


//--------------Chart data------------
const data1 = [10,12,8,10,15,9,7,8,9,10];
// const data2 = [1,1,2,2,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,17,17,18,19,20,21,22,23,24,25,26,27,28,29];
const labels = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"]
const data = {
    labels: labels,
    datasets: [
      {
        label: "No. of Appointment",
        data: data1,
        borderColor: "#00bf63"
      },
    //   {
    //     label: "Actual Progress",
    //     data: data2,
    //     fill: false,
    //     borderColor: "#2242a3"
    //   }
    ],
  }

  const options = {
    scales: {
      x: {
        type: 'category', // Use 'category' scale for X-axis when using labels
        title: {
          display: true,
          text: 'Weeks',
        },
      },
      y: {
        title: {
          display: true,
          text: 'No. of Appointment',
        },
      },
    },
  };

export default function Dashboard() {
    const [open, setOpen] = React.useState(true);
    const [date, setDate] = React.useState(new Date())
    const toggleDrawer = () => {
        setOpen(!open);
    };
    

    return (
        <ThemeProvider theme={defaultTheme}>
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />
                <AppBar position="absolute" open={open}>
                    <Toolbar
                        sx={{
                            pr: '24px', // keep right padding when drawer closed
                            backgroundColor: "#f5f5f7",
                            border: "none"
                        }}
                    >
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={toggleDrawer}
                            sx={{
                                color: "#000",
                                marginRight: '36px',
                                ...(open && { display: 'none' }),
                            }}
                        >
                            <MenuIcon />
                        </IconButton>


                        <Typography
                            component="h1"
                            variant="h6"
                            color="#000"
                            noWrap
                            sx={{ flexGrow: 1 }}

                        >
                            Hi, Dr. Samantha Aggarwal
                        </Typography>

                        <IconButton color="inherit">
                            <Badge badgeContent={4} color="secondary" style={{ "margin-right": "30px" }}>
                                <NotificationsIcon style={{ fill: "#000" }} />
                            </Badge>
                            <PopupState variant="popover" popupId="demo-popup-menu">
                                {(popupState) => (
                                    <React.Fragment>
                                        <Avatar alt="Cindy Baker" {...bindTrigger(popupState)} src={require("../../images/person.jpg")} />
                                        <Menu {...bindMenu(popupState)}>
                                            <MenuItem onClick={popupState.close}><PersonOutlinedIcon /> Profile</MenuItem>
                                            <MenuItem onClick={popupState.close}><LogoutOutlinedIcon /> Logout</MenuItem>
                                        </Menu>
                                    </React.Fragment>
                                )}
                            </PopupState>

                        </IconButton>
                    </Toolbar>
                </AppBar>
                <Drawer variant="permanent" open={open} sx={{
                    backgroundColor: "#021138"
                }}>
                    <Toolbar
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            px: [1],
                            backgroundColor: "#021138",
                            border: "none"
                        }}
                    >
                        <IconButton onClick={toggleDrawer}>
                            {/* <p style={{
                                "display": "flex",
                                "margin": "auto",
                                "position": "relative",
                                "left": "-47%"
                            }}>Full Screen</p> */}
                            <MenuIcon sx={{
                                color: "#fff",
                                position: "absolute",
                                top: "22px",
                                right: '15px',
                            }} />
                            <img style={{
                                width: "210px"
                            }} src={require("../../images/speech4all.png")} alt='logo' />
                        </IconButton>
                    </Toolbar>
                    {/* <Divider /> */}
                    <List component="nav" sx={{
                        backgroundColor: "#021138",
                        color: "#fff",
                        height: "80%"
                    }}>
                        <Sideitems />
                        {/* <Divider sx={{ my: 1 }} /> */}
                        {/* {secondaryListItems} */}
                    </List>
                </Drawer>
                <Box
                    component="main"
                    sx={{
                        backgroundColor: '#fff',
                        flexGrow: 1,
                        height: '100vh',
                        overflow: 'auto',
                    }}
                >
                    <Toolbar />
                    <Container maxWidth="xxl" sx={{ mt: 4, mb: 4 }}>
                        <Grid container spacing={2}>
                            <Grid item xs={12} md={4} lg={3}>
                                <Paper
                                    sx={{
                                        p: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        height: 100,
                                        background: '#f4f1fe'
                                    }}
                                >
                                    <h4 style={{ "textAlign": 'center' }}>Total Session</h4>
                                    <h5 style={{ "textAlign": 'center' }}>25</h5>
                                </Paper>
                            </Grid>
                            <Grid item xs={12} md={4} lg={3}>
                                <Paper
                                    sx={{
                                        p: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        height: 100,
                                        background: '#e1eefb'
                                    }}
                                >
                                    <h4 style={{ "textAlign": 'center' }}>Total Patient</h4>
                                    <h5 style={{ "textAlign": 'center' }}>25</h5>
                                </Paper>
                            </Grid>

                            <Grid item xs={12} md={4} lg={3}>
                                <Paper
                                    sx={{
                                        p: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        height: 100,
                                        background: '#e7fde5'
                                    }}
                                >
                                    <h4 style={{ "textAlign": 'center' }}>Upcoming Session</h4>
                                    <h5 style={{ "textAlign": 'center' }}>5</h5>
                                </Paper>
                            </Grid>

                            <Grid item xs={12} md={4} lg={3}>
                                <Paper
                                    sx={{
                                        p: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        height: 100,
                                        background: '#fbedd2'
                                    }}
                                >
                                    <h4 style={{ "textAlign": 'center' }}>Payment Received</h4>
                                    <h5 style={{ "textAlign": 'center' }}>25K</h5>
                                </Paper>
                            </Grid>

                        </Grid>
                    </Container>
                    <Container maxWidth="xxl" sx={{ mt: 2 }}>
                        <h5>Upcoming appointment</h5>
                        <Grid container spacing={1} mt={2} sx={{
                            // maxWidth:'920px',
                            // width:"70vw"
                           display:"flex",
                           alignItems: "center"
                        }}>
                            <Grid item sm={12} md={7}>


                                <Grid item sx={{
                                    // padding:"10px 0",
                                    //  border:"1px solid #f5f5f7",
                                    //  borderRadius:"6px"
                                }}>
                                    <AppointmentCard status="upcoming" />
                                </Grid>
                                <Grid container sx={{mt:3}}>
                                <h5 style={{ marginTop: "20px" }}>Past appointment</h5>
                                </Grid>
                             
                                <Grid item sx={{ mt: 2, }}>
                                    <AppointmentCard status="past"/>
                                </Grid>
                                <Grid item sx={{ mt: 2, 
                                     }}>
                                    <AppointmentCard status="past"/>
                                </Grid>
                                <Grid item sx={{ mt: 2, 
                                     }}>
                                    <AppointmentCard status="past"/>
                                </Grid>
                               

                            </Grid>
                            <Grid item sm={12} md={5} sx={{
                                 display: "flex",
                                flexDirection:"column",
                                justifyContent: "flex-start",
                                alignItems: "center",
                                gap:"15px 0"
                            }}>
                                {/* <Calendar className="dashboardCalender" onChange={(d) => setDate(d)} /> */}
                               <div style={{border:"3px solid #f5f5f7"}}>
                                    <BasicDateCalendar/>
                               </div>
                                <Chart data={data} options={options}/>
                            </Grid>

                        </Grid>

                    </Container>

                </Box>
            </Box>
        </ThemeProvider>
    );
}
