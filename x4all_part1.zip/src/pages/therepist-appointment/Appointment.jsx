import * as React from 'react';
import { styled, createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Link from '@mui/material/Link';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
// import Sideitems from '../../components/SidenavbarItems/SideItems';
import Sideitems from '../../components/SidenavbarItems/SideItems';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import { LineChart, Line, CartesianGrid, XAxis, YAxis } from 'recharts';
import "./Appointment.css"
import AddIcon from '@mui/icons-material/Add';
import AppointmentCard from '../../components/therepist/AppointmentCard';

function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © Developed By '}
            <Link color="inherit" href="https://mui.com/">
                Rhombus
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const drawerWidth = 240;

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        '& .MuiDrawer-paper': {
            position: 'relative',
            whiteSpace: 'nowrap',
            width: drawerWidth,
            transition: theme.transitions.create('width', {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
            boxSizing: 'border-box',
            ...(!open && {
                overflowX: 'hidden',
                transition: theme.transitions.create('width', {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.leavingScreen,
                }),
                width: theme.spacing(7),
                [theme.breakpoints.up('sm')]: {
                    width: theme.spacing(9),
                },
            }),
        },
    }),
);

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

export default function Appointment() {
    const [open, setOpen] = React.useState(true);
    const toggleDrawer = () => {
        setOpen(!open);
    };
    // const data = [{name: 'Page A', uv: 400, pv: 2400, amt: 2400}];

    return (
        <ThemeProvider theme={defaultTheme}>
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />
                <AppBar position="absolute" open={open}>
                    <Toolbar
                        sx={{
                            pr: '24px', // keep right padding when drawer closed
                            backgroundColor:"#f5f5f7",
                            border:"none"
                        }}
                    >
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={toggleDrawer}
                            sx={{
                                color:"#000",
                                marginRight: '36px',
                                ...(open && { display: 'none' }),
                            }}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography
                            component="h1"
                            variant="h6"
                            color="#000"
                            noWrap
                            sx={{ flexGrow: 1 }}
                        >
                            Hi, Login User Name
                        </Typography>
                        <IconButton color="inherit">
                            <Badge badgeContent={4} color="secondary" style={{ "margin-right": "30px" }}>
                                <NotificationsIcon style={{fill:"#000"}}/>
                            </Badge>
                            <PopupState variant="popover" popupId="demo-popup-menu">
                                {(popupState) => (
                                    <React.Fragment>
                                        <Avatar alt="Cindy Baker" {...bindTrigger(popupState)} src={require("../../images/person.jpg")}  />
                                        <Menu {...bindMenu(popupState)}>
                                            <MenuItem onClick={popupState.close}><PersonOutlinedIcon /> Profile</MenuItem>
                                            <MenuItem onClick={popupState.close}><LogoutOutlinedIcon /> Logout</MenuItem>
                                        </Menu>
                                    </React.Fragment>
                                )}
                            </PopupState>

                        </IconButton>
                    </Toolbar>
                </AppBar>
                <Drawer variant="permanent" open={open} sx={{
                     backgroundColor:"#021138"
                }}>
                    <Toolbar
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            px: [1],
                            backgroundColor:"#021138",
                            border:"none"
                        }}
                    >
                        <IconButton onClick={toggleDrawer}>
                            {/* <p style={{
                                "display": "flex",
                                "margin": "auto",
                                "position": "relative",
                                "left": "-47%"
                            }}>Full Screen</p> */}
                            <MenuIcon sx={{
                                color:"#fff",
                                position:"absolute",
                                top:"22px",
                                right:'15px',
                                }}/>
                            <img style={{
                                width:"210px"
                            }} src={require("../../images/speech4all.png")} alt='logo'/>
                        </IconButton>
                    </Toolbar>
                    {/* <Divider /> */}
                    <List component="nav" sx={{
                        backgroundColor:"#021138",
                        color:"#fff",
                        height:"80%"
                    }}>
                        <Sideitems />
                        {/* <Divider sx={{ my: 1 }} /> */}
                        {/* {secondaryListItems} */}
                    </List>
                </Drawer>
                <Box
                    component="main"
                    sx={{
                        backgroundColor: (theme) =>
                            theme.palette.mode === 'light'
                                ? theme.palette.grey[100]
                                : theme.palette.grey[900],
                        flexGrow: 1,
                        height: '100vh',
                        overflow: 'auto',
                        padding: ' 0 10px'
                    }}
                >
                    <Toolbar />
                    <Container maxWidth="xl" sx={{
                        display:"flex",
                        justifyContent:"space-between", 
                        alignItems:"flex-start",
                        mt:4,
                        mb:4
                    }}>
                        <div>
                        <h5 style={{fontWeight:"600"}}>Upcoming appointment </h5>
                        <p>Your upcoming appointment</p>
                        </div>
                        <button className='addAppointmentBtn'>Add <span>an Appointment</span> <AddIcon /></button>
                    </Container>
                    <Container maxWidth="md" sx={{
                        mt: 4,
                        mb: 4,
                        backgroundColor: "#fff",
                        borderRadius: '10px',
                        padding: "25px 0",
                        display:"flex",
                        justifyContent:"center",
                        alignItems:"center",
                        flexDirection:"column",
                        gap:"30px 0"
                    }}>

                            <AppointmentCard status="upcoming" type="patient"/>
                            <AppointmentCard status="upcoming" type="patient"/>
                            <AppointmentCard status="upcoming" type="patient"/>
                          
                            
                       
                    </Container>
                    <Container maxWidth="xl" sx={{ 
                        mt:4,
                        mb:4
                    }}>
                        <div>
                            <h5 style={{fontWeight:"600"}}>Past appointment </h5>
                            <p>Your past appointment</p>
                        </div>
                        {/* <button className='addAppointmentBtn'>Add <span>an Appointment</span> <AddIcon /></button> */}
                    </Container>
                    <Container maxWidth="md" sx={{
                        mt: 4,
                        mb: 4,
                        backgroundColor: "#fff",
                        borderRadius: '10px',
                        padding: "25px 0",
                        display:"flex",
                        justifyContent:"center",
                        alignItems:"center",
                        flexDirection:"column",
                        gap:"30px 0"
                    }}>

                            <AppointmentCard status="past" type="therepist"/>
                            <AppointmentCard status="past" type="therepist"/>
                            <AppointmentCard status="past" type="therepist"/>
                    </Container>
                    
                </Box>
            </Box>
        </ThemeProvider >
    );
}
