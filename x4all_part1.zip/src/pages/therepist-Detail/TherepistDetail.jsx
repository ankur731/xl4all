import * as React from 'react';
import { styled, createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Link from '@mui/material/Link';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import Sideitems from '../../components/SidenavbarItems/SideItems';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { useModal, Modal } from 'react-morphing-modal';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import "../Patient/patientDetail/PatientDetail.css"
import { LineChart, Line, CartesianGrid, XAxis, YAxis } from 'recharts';
import { Button } from '@mui/material';
import DateCalendarServerRequest from '../../components/Calender';
import KeyboardBackspaceOutlinedIcon from '@mui/icons-material/KeyboardBackspaceOutlined';
import { useState } from 'react';
import { Fragment } from 'react';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import "./TherepistDetail.css"


function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © Developed By '}
            <Link color="inherit" href="https://mui.com/">
                Rhombus
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const drawerWidth = 240;

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        '& .MuiDrawer-paper': {
            position: 'relative',
            whiteSpace: 'nowrap',
            width: drawerWidth,
            transition: theme.transitions.create('width', {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
            boxSizing: 'border-box',
            ...(!open && {
                overflowX: 'hidden',
                transition: theme.transitions.create('width', {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.leavingScreen,
                }),
                width: theme.spacing(7),
                [theme.breakpoints.up('sm')]: {
                    width: theme.spacing(9),
                },
            }),
        },
    }),
);

// TODO remove, this demo shouldn't need to reset the theme.
const defaultTheme = createTheme();

export default function Therepistdetail() {
    const [open, setOpen] = useState(true);
    // const [feedback, setFeedback] = useState(true);
    // const toggleFeedback = () => {
    //     console.log("Clicked"+feedback)
    //     setFeedback(!feedback);
    // }


    const toggleDrawer = () => {
        setOpen(!open);
    };
    const { modalProps, getTriggerProps } = useModal({
        background: '#21252994;',
    });
    // const data = [{name: 'Page A', uv: 400, pv: 2400, amt: 2400}];
    function goToBack() {
        window.location.href = "/patient/appointment";
    }
    return (
        <ThemeProvider theme={defaultTheme}>
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />
                <AppBar position="absolute" open={open}>
                    <Toolbar
                        sx={{
                            pr: '24px', // keep right padding when drawer closed
                            backgroundColor: "#f5f5f7",
                            border: "none"
                        }}
                    >
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={toggleDrawer}
                            sx={{
                                color: "#000",
                                marginRight: '36px',
                                ...(open && { display: 'none' }),
                            }}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography
                            component="h1"
                            variant="h6"
                            color="#000"
                            noWrap
                            sx={{ flexGrow: 1 }}
                        >
                            Hi, Login User Name
                        </Typography>
                        <IconButton color="inherit">
                            <Badge badgeContent={4} color="secondary" style={{ "margin-right": "30px" }}>
                                <NotificationsIcon style={{ fill: "#000" }} />
                            </Badge>
                            <PopupState variant="popover" popupId="demo-popup-menu">
                                {(popupState) => (
                                    <Fragment>
                                        <Avatar alt="Cindy Baker" {...bindTrigger(popupState)} src={require("../../images/person.jpg")} />
                                        <Menu {...bindMenu(popupState)}>
                                            <MenuItem onClick={popupState.close}><PersonOutlinedIcon /> Profile</MenuItem>
                                            <MenuItem onClick={popupState.close}><LogoutOutlinedIcon /> Logout</MenuItem>
                                        </Menu>
                                    </Fragment>
                                )}
                            </PopupState>

                        </IconButton>
                    </Toolbar>
                </AppBar>
                <Drawer variant="permanent" open={open} sx={{
                    backgroundColor: "#021138"
                }}>
                    <Toolbar
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            px: [1],
                            backgroundColor: "#021138",
                            border: "none"
                        }}
                    >
                        <IconButton onClick={toggleDrawer}>
                            {/* <p style={{
                                "display": "flex",
                                "margin": "auto",
                                "position": "relative",
                                "left": "-47%"
                            }}>Full Screen</p> */}
                            <MenuIcon sx={{
                                color: "#fff",
                                position: "absolute",
                                top: "22px",
                                right: '15px',
                            }} />
                            <img style={{
                                width: "210px"
                            }} src={require("../../images/speech4all.png")} alt='logo' />
                        </IconButton>
                    </Toolbar>
                    {/* <Divider /> */}
                    <List component="nav" sx={{
                        backgroundColor: "#021138",
                        color: "#fff",
                        height: "80%"
                    }}>
                        <Sideitems />
                        {/* <Divider sx={{ my: 1 }} /> */}
                        {/* {secondaryListItems} */}
                    </List>
                </Drawer>
                <Box
                    component="main"
                    sx={{
                        backgroundColor: (theme) =>
                            theme.palette.mode === 'light'
                                ? theme.palette.grey[100]
                                : theme.palette.grey[900],
                        flexGrow: 1,
                        height: '100vh',
                        overflow: 'auto',
                        padding: ' 0 10px'
                    }}
                >
                    <Toolbar />
                    <Container sx={{
                        mt: 4,
                        mb: 4,
                        paddingLeft: "0px"
                    }}>
                        <Grid item sx={{
                            paddingLeft: "0px"
                        }}>
                            <p style={{ fontWeight: "bold" }} onClick={goToBack}><KeyboardBackspaceOutlinedIcon /> Back to list</p>
                        </Grid>
                    </Container>
                    <Container maxWidth="lg" sx={{
                        mt: 4,
                        mb: 4,
                        backgroundColor: "#fff",
                        borderRadius: '10px',
                        padding: "15px 0 10px 0"
                    }}>
                        <Grid container spacing={3} sx={{
                            alignItems: "center",
                            padding: "10px"
                        }}>
                            <Grid item xs={2}>
                                <img className='patient-detail-img' src={require('../../images/person.jpg')} alt='personImg' />
                            </Grid>
                            <Grid item xs={5}>
                                <h6><strong>Abhsihek patil</strong></h6>
                                <p>London, UK ( GMT+05:30 )</p>
                                <p style={{ margin: "0" }}>10+ years of Experince</p>
                            </Grid>
                            <Grid item className='bookAppointmentBtnSection' style={{ display: "flex", flexDirection: "column", alignItems: "center", }}>
                                <p style={{ marginBottom: "5px" }}>Available Today</p>
                                <button {...getTriggerProps()} className='bookAppointmentBtn'>Book an appointment</button>
                                <Modal {...modalProps}>

                                    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
                                        <Grid container spacing={2} sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}>

                                            <Grid item xs={12} md={12} lg={8}>

                                                <Paper

                                                    sx={{
                                                        p: 2,
                                                        display: 'flex',
                                                        flexDirection: 'column',
                                                        height: 'auto',
                                                    }}
                                                >
                                                    <h5>Select Slot</h5>
                                                    <DateCalendarServerRequest />
                                               <form>
                                                        <Grid container maxWidth="md" spacing={2}

                                                            sx={{
                                                                display: 'flex',
                                                                flexDirection: 'row',
                                                                textAlign: 'center',
                                                                gap:"20px 15px",
                                                                justifyContent: "center",
                                                                alignItems: "center"

                                                            }}
                                                        >

                                                            <Grid item xs={9} sm={5} md={4} lg={5} className='time-button'>
                                                                <input type="radio" id="a25" name="check-substitution-2" />
                                                                <label class="btn btn-default" for="a25">02:30-03:30</label>
                                                            </Grid>

                                                            <Grid item xs={9} sm={5} md={4} lg={5} className='time-button'>
                                                                <input type="radio" id="a25" name="check-substitution-2" />
                                                                <label class="btn btn-default" for="a25">02:30-03:30</label>
                                                            </Grid>
                                                            <Grid item xs={9} sm={5} md={4} lg={5}  className='time-button'>
                                                                <input type="radio" id="a25" name="check-substitution-2" />
                                                                <label class="btn btn-default" for="a25">02:30-03:30</label>
                                                            </Grid>
                                                            <Grid item xs={9} sm={5} md={4} lg={5} className='time-button'>
                                                                <input type="radio" id="a25" name="check-substitution-2" />
                                                                <label class="btn btn-default" for="a25">02:30-03:30</label>
                                                            </Grid>



                                                         



                                                        </Grid>
                                                        </form>
                                                    <Grid container sx={{
                                                        display: "flex",
                                                        justifyContent: "center",
                                                        alignItems: "center",
                                                        marginTop: "20px",
                                                    }}>
                                                        <Grid item>
                                                            <button style={{ padding: "8px 30px", border: "none", borderRadius: "5px", backgroundColor: '#00bf63', color: "#fff" }}>Confirm</button>
                                                        </Grid>
                                                    </Grid>
                                                </Paper>

                                            </Grid>
                                        </Grid>

                                    </Container>
                                </Modal>
                            </Grid>

                        </Grid>

                        <Grid sx={{
                            mt: 3
                        }}>
                            <h5 style={{ fontWeight: "bold" }}>Bio</h5>
                            <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</p>
                        </Grid>
                        <Grid sx={{
                            mt: 3
                        }}>
                            <button style={{ backgroundColor: "#00BF63", color: "#fff", borderRadius: "5px", padding: "8px 25px", border: "none" }}>Give Feedback</button>


                        </Grid>
                        <Grid sx={{
                            mt: 3
                        }}>
                            <h5 style={{ fontWeight: "bold" }}>Last Review</h5>
                            <p>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</p>
                        </Grid>




                        {/* <Copyright sx={{ pt: 4 }} /> */}
                    </Container>

                </Box>
            </Box>
        </ThemeProvider >
    );
}
