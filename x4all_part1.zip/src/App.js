import React from 'react';
// import ReactDOM from 'react-dom/client';
import './App.css';
// import Home from './components/patient/Home';
// import Dashboard from './pages/Dashboard/Dashboard';
import { BrowserRouter as Router,Routes, Route } from 'react-router-dom';
import Patients from './pages/Patient/Patients';
import Patientdetail from './pages/Patient/patientDetail/PatientDetail';
// import Calender from './pages/Calender/Calender';
import Calender from './pages/therepist-Calender/Calender';
import Dashboard from './pages/therepist-Dashboard/Dashboard';
import Appointment from './pages/therepist-appointment/Appointment';
import PatientDashboard from './pages/patient-Dashboard/Dashboard';
import PatientAppointment from './pages/patient-Appointment/Appointment';
import Therepistdetail from './pages/therepist-Detail/TherepistDetail';
import SignIn from './components/Auth/Login/Login';
import SignUp from './components/Auth/Signup/Logout';
import Forgot from './components/Auth/Forgot/Forgot';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
function App() {
  return (
    <div className="App">
      {/* <Dashboard /> */}
      <Router>
      <Routes>
        <Route path="/login" element={<SignIn />}/>
        <Route path="/signup" element={<SignUp />}/>
        <Route path="/forgot" element={<Forgot />}/>
        <Route path="/therepist" element={<Dashboard />}/>
        {/* <Route path="/therepist-appointment" element={<Patients />} /> */}
        <Route path="/therepist/patient" element={<Patients />} />
        <Route path="/therepist/patient/patient-detail" element={<Patientdetail />} />
        <Route path="/therepist/calender" element={<Calender />} />
        <Route path="/therepist/appointment" element={<Appointment />} />
        <Route path="/patient" element={<PatientDashboard />} />
        <Route path="/patient/appointment" element={<PatientAppointment />} />
        <Route path="/patient/therepist/therepist-detail" element={<Therepistdetail />} />
      </Routes>
      </Router>
       <ToastContainer />
    </div>
  );
}

export default App;
