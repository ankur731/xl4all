import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import DateRangeOutlinedIcon from '@mui/icons-material/DateRangeOutlined';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';

const Sideitems = () => {
   
    function gotohome(){
        // console.log(window.loaction.pathname)
        window.location.href="/therepist"
    }
    function gotoappointment(){
        window.location.href="/therepist/appointment"
    }
    function gotopatient(){
        window.location.href="/therepist/patient"
    }
    function gotocalender(){
        window.location.href="/therepist/calender"
    }
    function patientsdashboard(){
        window.location.href="/patient"
    }
    function patientsappointment(){
        window.location.href="/patient/appointment"
    }
 
    return (
        <>
            <ListItemButton onClick={gotohome}>
                <ListItemIcon>
                    <HomeOutlinedIcon sx={{ color: '#fff' }}/>
                </ListItemIcon>
                <ListItemText primary="Dashboard" />
            </ListItemButton>
            <ListItemButton onClick={gotoappointment}>
                <ListItemIcon>
                   <DateRangeOutlinedIcon sx={{ color: '#fff' }}/>
                </ListItemIcon>
                <ListItemText primary="Appointment" />
            </ListItemButton>
            <ListItemButton onClick={gotopatient}>
                <ListItemIcon>
                   <PersonOutlinedIcon sx={{ color: '#fff' }}/>
                </ListItemIcon>
                <ListItemText primary="Patient" />
            </ListItemButton>
            <ListItemButton onClick={gotocalender}>
                <ListItemIcon>
                   <CalendarTodayIcon sx={{ color: '#fff' }}/>
                </ListItemIcon>
                <ListItemText primary="Calender" />
            </ListItemButton>
            <ListItemButton >
               
               <ListItemText primary="Patient PoV" />
           </ListItemButton>
          
           <ListItemButton onClick={patientsdashboard}>
               <ListItemIcon>
                  <CalendarTodayIcon sx={{ color: '#fff' }}/>
               </ListItemIcon>
               <ListItemText primary="Dashboard" />
           </ListItemButton>
           <ListItemButton onClick={patientsappointment}>
               <ListItemIcon>
                  <CalendarTodayIcon sx={{ color: '#fff' }}/>
               </ListItemIcon>
               <ListItemText primary="Appointment" />
           </ListItemButton>
        </>
    );
};

export default Sideitems;