import React, { useState } from 'react'
import "./AppointmentCard.css";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import DateRangeIcon from '@mui/icons-material/DateRange';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import BusinessCenterOutlinedIcon from '@mui/icons-material/BusinessCenterOutlined';
import ActivityPage from '../ActivityPage';
import { toast } from 'react-toastify';

function AppointmentCard(props) {

  const [action, setAction] = useState(false);
  const [activity, setActivity] = useState(false);
  const handleClick = (status) => {
    if(status==="upcoming") {
      setAction(!action);
    }
    else {
        setActivity(!activity);
    }
  };


  function appointmentCardClicked() {
    var type;
    if(props.type==="therepist"){
      type = "patient/therepist/therepist-detail";
    }
    else {
      type = "therepist/patient/patient-detail";
    }
    window.location.href=`/${type}`;
  }
  return (
<>
    <div className='row appointmentCard' >
      <div className='col col-xs-12 col-md-5  imgContent' >

        <div className='therepistImgDiv' onClick={appointmentCardClicked}>
          <img className='therepistImg' src={require("../../images/person.jpg")} alt='appimg' />
        </div>
        <div className='therepistContent'>
          <h5 onClick={appointmentCardClicked}>Emilia Winson</h5>
          <p>London, UK</p>
          {props.type==='therepist'&&<p><BusinessCenterOutlinedIcon /> 10+ years</p>}
          
        </div>

      </div>
      <div className='col col-xs-12 col-md-6 row btnGroup ' >
          <div className="dateTime-btn col-12 ">
              <p><DateRangeIcon /> 19 July 2023</p>
              <p><AccessTimeOutlinedIcon /> 12:00 PM</p>
          </div>

         
        <div className='row col-12 bottomBtnDiv justify-content-between'  >

       
        <div className="action-btn col-5" onClick={()=>handleClick(props.status)}>{props.status==='upcoming'?"Action":"Activity"} <KeyboardArrowDownIcon />
       {action &&<div className='action-div' >
            <h5>Reshedule</h5>
            <hr />
            <h5>Cancel</h5>
        </div>
      }
        </div>
       
          <div className="join-btn col-6">{props.status==='upcoming'?"Join":"Recording"}</div>
          </div>
      </div>
    </div>
    {activity&&
    <div className='row'>
       <ActivityPage who={props.type}/>
    </div>
    }
    </>
  )
}

export default AppointmentCard
