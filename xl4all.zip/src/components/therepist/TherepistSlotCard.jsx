import React from 'react'

function TherepistSlotCard() {
  return (
    <div >
        <h6>19 July</h6>
        <p>10:00 AM - 11:00 AM</p>  
    </div>
  )
}

export default TherepistSlotCard
